import axios from "axios";

interface OpenAIResponse {
  choices: {
    text: string;
  }[];
}

async function sendPromptToOpenAI(prompt: string): Promise<string> {
  const url = "https://api.openai.com/v1/engines/text-curie-001/completions";
  const headers = {
    Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
    "Content-Type": "application/json",
  };
  const data = {
    prompt,
    max_tokens: 2048,
    temperature: 0.5,
  };

  try {
    const response = await axios.post<OpenAIResponse>(url, data, { headers });
    return response.data.choices[0].text;
  } catch (error) {
    console.error(error);
    throw error;
  }
}

export default sendPromptToOpenAI;


