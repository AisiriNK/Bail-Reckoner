> !!! NOTE: DO NOT COMMIT UPDATES ON THE MAIN BRANCH !!!

# Setup Instructions:

> These two steps below are common for both workers on the frontend and backend

1. run `git clone https://github.com/OmkarSathish/SIH-Bail-Reckoner.git`
2. run `cd SIH-Bail-Reckoner`

## Initialization instruction for workers on the Frontend

1. run `git checkout -b frontend`

> In case an error like this is thrown `fatal: a branch named 'frontend' already exists`, run `git switch frontend`

2. run `cd client/`
3. run `npm install`
4. run `npm run dev`

## Initialization instruction for workers on the Backend

1. run `git checkout -b backend`

> In case an error like this is thrown `fatal: a branch named 'backend' already exists`, run `git switch backend`

2. run `cd server/`
3. run `npm install`
4. run `npm run dev`

## Push instruction for Frontend workers

1. run `git checkout frontend`
2. run `git pull origin frontend`
3. run `npm install`

> Start working on the feature or the change
> After working -

4. run `git add .`

> commit message must be short and should signify the change you've made or the feature added

5. run `git commit -m "<commit_message>"`
6. run `cd ../`
7. git `git push origin frontend`

## Push instruction for Backend workers

1. run `git checkout backend`
2. run `git pull origin backend`
3. run `git add .`

> Start working on the feature or the change
> After working -

4. run `git add .`

> commit message must be short and should signify the change you've made or the feature added

5. run `git commit -m "<commit_message>"`
6. run `cd ../`
7. git `git push origin backend`
